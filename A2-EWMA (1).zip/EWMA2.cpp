#include<iostream>
#include<cstdlib>
#include<cfloat>

using namespace std;

int main(const int argc,const char* const argv[])
{
  int max_count=1;
  int min_count=1;
  float alpha = atof(argv[1]);
  float age = atof(argv[2]);
  if( age <= 0 || alpha >= 1 || alpha <= 0 || argc < 4)
  {
    cerr<<"Your input is invalid or insufficiant arguments.";
    return -1;
  }

  float a;
  int i = 3 ;
  float min = FLT_MAX ;
  float max = FLT_MIN ;
  float sum=0;
  float avg=0;
  cout << "Sample  Value  Minimum  EWMA    Maximum" << endl;

  while(i <= (argc-1))
  {
    a = atof(argv[i]) ;
    if(a < min || min_count >= age)
    {
      min = a ;
      min_count = 1;
    }
    else
    {
      min_count++;
    }
    if(a>max || max_count >= age)
    {
      max = a;
      max_count = 1;
    }
    else
    ++max_count;
    if(i==3)
    avg = a;
    cout << i-2 << "\t" << a << "\t" << min << "\t" << (alpha*a)+((1-alpha)*avg) << "\t" << max << endl;
    avg= (alpha*a)+((1-alpha)*avg);
    ++i;
  }
  return 0;
}
