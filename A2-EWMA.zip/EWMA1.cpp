#include<iostream>
#include<cstdlib>
#include<cfloat>

using namespace std;

int main(const int argc,const char* const argv[])
{
  float alpha = atof(argv[1]);

  if(argc <= 2 || alpha >= 1 ||alpha <= 0 )
  {
     cout << "Unable to compute statistics over data set because there is an invalid input." << endl;
     return -1;
  }

  float a;
  int i = 3 ;
  float min = FLT_MAX ;
  float max = FLT_MIN ;
  float sum=0;
  float avg=0;
  cout << "Sample  Value  Minimum  EWMA    Maximum" << endl;

  while(i <= (argc-1))
  {
     a = atof(argv[i]) ;
     if(a<min)
     min = a ;
     if(a>max)
     max = a;
     if(i==3)
     avg = a;
     cout << i-2 << "\t" << a << "\t" << min << "\t" << (alpha*a)+((1-alpha)*avg) << "\t" << max << endl;
     avg= (alpha*a)+((1-alpha)*avg);
     ++i;
  }
  return 0;
}
