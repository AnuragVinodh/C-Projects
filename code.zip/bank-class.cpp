#include <iostream>
using namespace std;

// ---------- "Hands-On: Better with Class" ----------
class Account {
public:
     // your code here
private:
     // your code here
};
// ---------- "Hands-On: Better with Class" ----------

const int count = 2;
Account accounts[count];

// ----------- "Hands-On: Use Your Class" -------------
int main(const int argc, const char *argv[])
{
    // input error checking goes here...
    int withdraw_account = atoi(argv[1]);
    float amount = atof(argv[2]);

    // your code here
     
     return 0;
}
// ----------- "Hands-On: Use Your Class" -------------
